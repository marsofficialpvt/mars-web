import { motion } from "motion/react";
import { CheckCircle2, Users, DollarSign, MessageSquare, Bus, BarChart3, Bell, GraduationCap, Calendar, ClipboardCheck } from "lucide-react";
import { ImageWithFallback } from "./ImageWithFallback";

const problems = [
  {
    icon: Bus,
    title: "Live Bus Tracking",
    description: "Real-time GPS tracking of school buses with parent notifications and route optimization",
  },
  {
    icon: Users,
    title: "Student Management",
    description: "Complete student lifecycle management from admission to alumni with comprehensive profiles",
  },
  {
    icon: MessageSquare,
    title: "Instant Communication",
    description: "Direct messaging between teachers, parents, and administration for seamless collaboration",
  },
  {
    icon: DollarSign,
    title: "Streamlined Fee Collection",
    description: "Online payments, automated reminders, and instant receipt generation",
  },
  {
    icon: BarChart3,
    title: "Performance Analytics",
    description: "Comprehensive grade tracking, progress reports, and data-driven insights",
  },
  {
    icon: Bell,
    title: "Smart Notifications",
    description: "School-level and class-level announcements with targeted delivery and read receipts",
  },
  {
    icon: Calendar,
    title: "Attendance Management",
    description: "Digital attendance tracking with biometric integration and automated absence alerts",
  },
  {
    icon: ClipboardCheck,
    title: "Exam & Assignment Tracking",
    description: "Centralized exam scheduling, assignment submission, and grading management system",
  },
];

export function SchoolERPSection() {
  return (
    <section id="erp" className="py-32 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 backdrop-blur-sm mb-6">
            <span className="text-sm text-blue-300 font-semibold">FLAGSHIP SOLUTION</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Next-Gen School ERP & CRM
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
            Transform your educational institution with an all-in-one platform that eliminates administrative bottlenecks and modernizes campus operations
          </p>
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1643199121319-b3b5695e4acb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080"
                alt="Modern digital classroom with technology"
                className="w-full h-[600px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
            </div>

            {/* Floating Stats Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="absolute -bottom-6 -right-6 bg-gradient-to-br from-blue-600 to-purple-600 p-6 rounded-2xl shadow-2xl border border-white/10"
            >
              <div className="text-white">
                <div className="text-4xl font-bold mb-1">85%</div>
                <div className="text-sm text-blue-100">Administrative Time Saved</div>
              </div>
            </motion.div>
          </motion.div>

          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h3 className="text-3xl font-bold text-white mb-4">
                The Complete School Management Solution
              </h3>
              <p className="text-lg text-slate-300 leading-relaxed">
                Our tailored ERP & CRM platform addresses every challenge modern educational institutions face. From enrollment to graduation, we've got you covered with intelligent automation and seamless integration.
              </p>
            </div>

            <div className="space-y-4">
              {[
                "Reduce administrative workload by 85%",
                "Improve parent engagement by 3x",
                "Real-time data access from anywhere",
                "Mobile-first design for on-the-go management",
              ].map((benefit, index) => (
                <motion.div
                  key={benefit}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-3"
                >
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center mt-1">
                    <CheckCircle2 className="w-4 h-4 text-white" />
                  </div>
                  <p className="text-slate-300 text-lg">{benefit}</p>
                </motion.div>
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-semibold shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all"
            >
              See How It Works
            </motion.button>
          </motion.div>
        </div>

        {/* Features Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-24"
        >
          <h3 className="text-3xl font-bold text-white text-center mb-12">
            Problems We Solve
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {problems.map((problem, index) => (
              <motion.div
                key={problem.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="p-6 rounded-xl bg-slate-900/50 backdrop-blur-sm border border-slate-800 hover:border-blue-500/50 transition-all group"
              >
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <problem.icon className="w-6 h-6 text-blue-400" />
                </div>
                <h4 className="text-lg font-semibold text-white mb-2">
                  {problem.title}
                </h4>
                <p className="text-sm text-slate-400">
                  {problem.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
