import { motion } from "motion/react";
import { Code2, Zap, Palette, Rocket } from "lucide-react";

const features = [
  {
    icon: Code2,
    title: "Single Codebase",
    description: "Write once, deploy everywhere. Build for iOS, Android, web, and desktop from a unified codebase, reducing development time by 60%.",
    stat: "60%",
    statLabel: "Faster Development",
    color: "blue",
  },
  {
    icon: Zap,
    title: "Native Performance",
    description: "Compiled to native ARM code for blazing-fast performance. No bridge, no compromises. Your apps run at native speed.",
    stat: "120 FPS",
    statLabel: "Smooth Animations",
    color: "purple",
  },
  {
    icon: Palette,
    title: "Beautiful UI",
    description: "Pixel-perfect designs with Material Design and Cupertino widgets. Create stunning, brand-consistent experiences across all platforms.",
    stat: "∞",
    statLabel: "Design Possibilities",
    color: "pink",
  },
  {
    icon: Rocket,
    title: "Fast Deployment",
    description: "Hot reload for instant updates during development. Ship updates faster and iterate with confidence. From idea to production in weeks.",
    stat: "< 1 sec",
    statLabel: "Hot Reload Time",
    color: "cyan",
  },
];

const colorMap = {
  blue: {
    gradient: "from-blue-500 to-cyan-500",
    bg: "bg-blue-500/10",
    border: "border-blue-500/20",
    text: "text-blue-400",
  },
  purple: {
    gradient: "from-purple-500 to-pink-500",
    bg: "bg-purple-500/10",
    border: "border-purple-500/20",
    text: "text-purple-400",
  },
  pink: {
    gradient: "from-pink-500 to-rose-500",
    bg: "bg-pink-500/10",
    border: "border-pink-500/20",
    text: "text-pink-400",
  },
  cyan: {
    gradient: "from-cyan-500 to-blue-500",
    bg: "bg-cyan-500/10",
    border: "border-cyan-500/20",
    text: "text-cyan-400",
  },
};

export function WhyFlutter() {
  return (
    <section id="why-flutter" className="py-24 bg-slate-900 relative overflow-hidden">
      {/* Background Gradient Orbs */}
      <div className="absolute top-1/4 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Why We Choose{" "}
            <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              Flutter
            </span>
          </h2>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            The most powerful framework for building high-performance, cross-platform applications
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {features.map((feature, index) => {
            const colors = colorMap[feature.color as keyof typeof colorMap];
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15 }}
                className="group relative"
              >
                <div className={`relative p-8 rounded-2xl bg-slate-950/50 backdrop-blur-sm border ${colors.border} hover:border-opacity-50 transition-all`}>
                  {/* Header */}
                  <div className="flex items-start justify-between mb-6">
                    <div className={`p-4 rounded-xl bg-gradient-to-br ${colors.gradient}`}>
                      <feature.icon className="w-8 h-8 text-white" />
                    </div>
                    <div className="text-right">
                      <div className={`text-3xl font-bold ${colors.text}`}>
                        {feature.stat}
                      </div>
                      <div className="text-xs text-slate-500 uppercase tracking-wide">
                        {feature.statLabel}
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="text-2xl font-bold text-white mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-slate-400 leading-relaxed">
                    {feature.description}
                  </p>

                  {/* Hover Glow */}
                  <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${colors.gradient} opacity-0 group-hover:opacity-5 transition-opacity -z-10 blur-xl`} />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Tech Stack Highlights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-20 p-8 rounded-2xl bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 backdrop-blur-sm"
        >
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-white mb-2">Dart</div>
              <div className="text-slate-400">Modern, Type-Safe Language</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-white mb-2">Skia</div>
              <div className="text-slate-400">High-Performance Graphics Engine</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-white mb-2">Google</div>
              <div className="text-slate-400">Backed by Industry Leader</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
