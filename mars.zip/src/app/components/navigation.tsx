import { motion } from "motion/react";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/50">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              <span className="text-white font-bold text-xl">M</span>
            </div>
            <div>
              <div className="text-white font-bold text-lg leading-tight">
                Multi Architecture & Research Solutions
              </div>
              <div className="text-blue-400 text-xs font-semibold tracking-wider">
                MARS
              </div>
            </div>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#solutions" className="text-slate-300 hover:text-blue-400 transition-colors">
              Solutions
            </a>
            <a href="#erp" className="text-slate-300 hover:text-blue-400 transition-colors">
              School ERP
            </a>
            <a href="#crm" className="text-slate-300 hover:text-blue-400 transition-colors">
              CRM
            </a>
            <a href="#why-flutter" className="text-slate-300 hover:text-blue-400 transition-colors">
              Technology
            </a>
            <a href="#contact" className="text-slate-300 hover:text-blue-400 transition-colors">
              Contact
            </a>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold"
            >
              Get Started
            </motion.button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 text-white"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden pt-4 pb-2 space-y-3"
          >
            <a href="#solutions" className="block text-slate-300 hover:text-blue-400 transition-colors py-2">
              Solutions
            </a>
            <a href="#erp" className="block text-slate-300 hover:text-blue-400 transition-colors py-2">
              School ERP
            </a>
            <a href="#crm" className="block text-slate-300 hover:text-blue-400 transition-colors py-2">
              CRM
            </a>
            <a href="#why-flutter" className="block text-slate-300 hover:text-blue-400 transition-colors py-2">
              Technology
            </a>
            <a href="#contact" className="block text-slate-300 hover:text-blue-400 transition-colors py-2">
              Contact
            </a>
            <button className="w-full px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold">
              Get Started
            </button>
          </motion.div>
        )}
      </div>
    </nav>
  );
}
