import { motion } from "motion/react";
import { Github, Linkedin, Twitter, Mail, Instagram } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white">
              Multi Architecture & Research Solutions
            </h3>
            <div className="text-blue-400 text-sm font-semibold tracking-wider mb-2">
              MARS
            </div>
            <p className="text-slate-400 text-sm leading-relaxed">
              Building next-generation ERP and CRM solutions with Flutter. Empowering educational institutions to scale and succeed.
            </p>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">Flutter Development</a></li>
              <li><a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">School ERP & CRM</a></li>
              <li><a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">Enterprise Solutions</a></li>
              <li><a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">Custom CRM</a></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">About Us</a></li>
              <li><a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">Case Studies</a></li>
              <li><a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">Careers</a></li>
              <li><a href="#" className="text-slate-400 hover:text-blue-400 transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="text-white font-semibold mb-4">Connect</h4>
            <div className="flex gap-3">
              <motion.a
                href="https://instagram.com/mars.innovate"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:bg-gradient-to-br hover:from-purple-500/20 hover:to-pink-500/20 hover:text-pink-400 transition-all"
              >
                <Instagram className="w-5 h-5" />
              </motion.a>
              <motion.a
                href="mailto:Mars.official.pvt@gmail.com"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:bg-blue-500/10 hover:text-blue-400 transition-all"
              >
                <Mail className="w-5 h-5" />
              </motion.a>
              <motion.a
                href="tel:+916374356433"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:bg-blue-500/10 hover:text-blue-400 transition-all"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </motion.a>
            </div>
            <div className="mt-4 text-sm text-slate-400">
              <div className="mb-1">@mars.innovate</div>
              <div>Mars.official.pvt@gmail.com</div>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-500 text-sm">
            © 2026 Multi Architecture & Research Solutions (MARS). All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-slate-500 hover:text-blue-400 transition-colors">Privacy Policy</a>
            <a href="#" className="text-slate-500 hover:text-blue-400 transition-colors">Terms of Service</a>
            <a href="#" className="text-slate-500 hover:text-blue-400 transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
