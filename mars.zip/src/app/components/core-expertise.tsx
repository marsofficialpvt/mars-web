import { motion } from "motion/react";
import { Smartphone, Code, Users, Building2 } from "lucide-react";

const expertise = [
  {
    icon: Smartphone,
    title: "Flutter App Development",
    description: "Build beautiful, natively compiled applications for mobile, web, and desktop from a single codebase.",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    icon: Code,
    title: "Android Apps",
    description: "Native Android applications optimized for performance, scalability, and user experience.",
    gradient: "from-green-500 to-emerald-500",
  },
  {
    icon: Users,
    title: "Custom CRM Systems",
    description: "Tailored customer relationship management solutions that adapt to your unique business processes.",
    gradient: "from-purple-500 to-pink-500",
  },
  {
    icon: Building2,
    title: "Enterprise ERP Solutions",
    description: "Comprehensive enterprise resource planning systems that unify your entire organization.",
    gradient: "from-orange-500 to-red-500",
  },
];

export function CoreExpertise() {
  return (
    <section id="solutions" className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(59,130,246,0.05),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(168,85,247,0.05),transparent_50%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Our Core Expertise
          </h2>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto">
            Delivering cutting-edge solutions across multiple platforms and technologies
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {expertise.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="group relative"
            >
              <div className="relative p-8 rounded-2xl bg-slate-900/50 backdrop-blur-sm border border-slate-800 hover:border-slate-700 transition-all h-full">
                {/* Icon with gradient background */}
                <div className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${item.gradient} mb-6`}>
                  <item.icon className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-xl font-bold text-white mb-3">
                  {item.title}
                </h3>
                <p className="text-slate-400 leading-relaxed">
                  {item.description}
                </p>

                {/* Hover Glow Effect */}
                <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${item.gradient} opacity-0 group-hover:opacity-5 transition-opacity -z-10 blur-xl`} />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
