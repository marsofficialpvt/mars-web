import { motion } from "motion/react";
import { Target, TrendingUp, Users, BarChart2, MapPin, DollarSign } from "lucide-react";

const crmFeatures = [
  {
    icon: Target,
    title: "Targeted Marketing & Geofencing",
    description: "Location-based marketing campaigns that reach prospective families in specific geographic areas with precision targeting",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    icon: TrendingUp,
    title: "Admissions & Revenue Analytics",
    description: "Track inquiries vs. conversion rates to optimize your admissions funnel and maximize enrollment",
    gradient: "from-purple-500 to-pink-500",
  },
  {
    icon: Users,
    title: "Administrative & Client Relationship",
    description: "Manage relationships with parents, students, and prospects through comprehensive CRM tools",
    gradient: "from-green-500 to-emerald-500",
  },
  {
    icon: BarChart2,
    title: "Income Bar Chart Analytics",
    description: "Visual revenue tracking and forecasting to understand financial trends and plan strategically",
    gradient: "from-orange-500 to-red-500",
  },
  {
    icon: MapPin,
    title: "Pinpoint Mapping: Territory Strategy",
    description: "Strategic territory mapping to identify growth opportunities and optimize marketing reach",
    gradient: "from-indigo-500 to-purple-500",
  },
  {
    icon: DollarSign,
    title: "Revenue Optimization",
    description: "Data-driven insights to increase conversion rates and maximize revenue per enrollment",
    gradient: "from-cyan-500 to-blue-500",
  },
];

export function CRMSection() {
  return (
    <section id="crm" className="py-24 bg-gradient-to-b from-slate-900 to-slate-950 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(168,85,247,0.08),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_70%,rgba(59,130,246,0.08),transparent_50%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/20 backdrop-blur-sm mb-6">
            <span className="text-sm text-purple-300 font-semibold">GROWTH & ANALYTICS</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Intelligent CRM Solutions
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
            Drive enrollment growth and optimize revenue with data-driven insights and strategic marketing tools
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {crmFeatures.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="group relative"
            >
              <div className="relative p-8 rounded-2xl bg-slate-900/50 backdrop-blur-sm border border-slate-800 hover:border-slate-700 transition-all h-full">
                {/* Icon with gradient background */}
                <div className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${feature.gradient} mb-6`}>
                  <feature.icon className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-xl font-bold text-white mb-3">
                  {feature.title}
                </h3>
                <p className="text-slate-400 leading-relaxed">
                  {feature.description}
                </p>

                {/* Hover Glow Effect */}
                <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-5 transition-opacity -z-10 blur-xl`} />
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-20 p-10 rounded-2xl bg-gradient-to-r from-purple-500/10 via-blue-500/10 to-cyan-500/10 border border-purple-500/20 backdrop-blur-sm text-center"
        >
          <h3 className="text-3xl font-bold text-white mb-4">
            Ready to Transform Your Enrollment Process?
          </h3>
          <p className="text-lg text-slate-300 mb-8 max-w-2xl mx-auto">
            Leverage advanced analytics and strategic marketing to grow your institution and maximize revenue
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl font-semibold shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 transition-all"
            >
              Schedule Demo
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-white/5 backdrop-blur-sm text-white rounded-xl font-semibold border border-white/10 hover:bg-white/10 transition-all"
            >
              View Case Studies
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
