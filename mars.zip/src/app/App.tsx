import { Navigation } from "./components/navigation";
import { HeroSection } from "./components/hero-section";
import { CoreExpertise } from "./components/core-expertise";
import { SchoolERPSection } from "./components/school-erp-section";
import { CRMSection } from "./components/crm-section";
import { WhyFlutter } from "./components/why-flutter";
import { ContactForm } from "./components/contact-form";
import { Footer } from "./components/footer";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950">
      <Navigation />
      <HeroSection />
      <CoreExpertise />
      <SchoolERPSection />
      <CRMSection />
      <WhyFlutter />
      <ContactForm />
      <Footer />
    </div>
  );
}